</div><!-- .container -->
<footer class="footer"><div class="inner" style="max-width:var(--max-w);margin:0 auto;display:flex;justify-content:space-between;align-items:center"><div>&copy; <?php echo date('Y'); ?> Neo News Hub</div><div style="color:var(--grey-light)">Built with care</div></div></footer>
<?php wp_footer(); ?></body></html>