<?php get_header(); ?>
<div class="container"><h1>404 — Not found</h1><p>Sorry, we couldn't find that page.</p></div>
<?php get_footer(); ?>