Neo News Hub WordPress theme

Installation:
1. Upload `neo-news-hub` folder to your WordPress `wp-content/themes/` directory.
2. Activate the theme in Appearance -> Themes.
3. Create a menu and assign to Primary Menu.

Fonts are enqueued from Google Fonts. Theme supports post thumbnails and title tag.